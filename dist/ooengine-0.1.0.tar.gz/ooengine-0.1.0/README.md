# OOEngine Info



## OOEngine version 0.1.0

Python version 3.10.11 (main, Apr  4 2023, 22:10:32) [GCC 12.2.0]

Branch by TheMadPunter

## OOEngine version 0.1.0

# How to Play

To play OOEngine, you can use commands to influence the world around you. Use the 

commands north, east, south, and west to move around, with "go somewhere" to go a 

specific place.



Command List

help

quit

north (n)

east (e)

south (s)

west (w)

look [object]

take [item]

eat [item]

inventory (i)

go [direction]

info

infogen



## UsernameLib version v1.0.0

### UsernameLib Help

Command list:

@username [username]

emote

say [tosay]

        



# Acknowledgements: 

Willie Crowther and Don Woods for Colossal Cave.





Debug: False